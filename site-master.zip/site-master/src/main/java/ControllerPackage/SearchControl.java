package ControllerPackage;

public class SearchControl {

		public boolean Simbols(String x) {
			if(x.matches(".*[/<>+$%#*&()]+.*")) {
				view = request.getRequestDispatcher(paginaErrore);
				response.addHeader("errorSearchMessage", message);
			}
			else view = request.getRequestDispatcher(paginaCatalogo);
		}
}
