package model;

public class game {
	
	private String name;
	private String years;
	private String added;
	private String img;
	private float price;
	private String desc;
	
	public game(String a,String b,String c,String d,float f,String g) {
		this.name=a;
		this.years=b;
		this.added=c;
		this.img=d;
		this.price=f;
		this.desc=g;
	}
	
	public String getName() {
		return name;
	}
	public String getYears() {
		return years;
	}
	public String getAdded() {
		return added;
	}
	public String getImg() {
		return img;
	}
	public float getPrice() {
		return price;
	}
	public String getDesc() {
		return desc;
	}
	public String toString(){
		return name + " " +years+ " " +added+ " " +img+ " " +price+ " " +desc;
		
	}

}
