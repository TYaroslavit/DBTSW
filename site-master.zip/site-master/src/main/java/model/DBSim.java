package model;
import  ControllerPackage.DriverManagerConnectionPool;
import model.game;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DBSim
 */
@WebServlet("/DBSim")
public class DBSim extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/*
	 * private Connection connect = null; private Statement statement = null;
	 * private PreparedStatement preparedStatement = null; private ResultSet
	 * resultSet = null;
	 */
    String titleGame;
	String release ;
	String added ;
	String img;
	float price ;
	String desc;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DBSim() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    
    private void db(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
    	Connection connection = null;
		PreparedStatement preparedStatement = null;

		Collection<game> gameList = new LinkedList<game>();

		String selectSQL = "SELECT * FROM gamemarket.games;";

		

		try {
			connection = DriverManagerConnectionPool.getConnection();
			
			  preparedStatement = connection.prepareStatement(selectSQL);
			  
			  ResultSet rs = preparedStatement.executeQuery();
			  
			  while (rs.next()) {
				  game gioco;
				  titleGame = rs.getString("nome"); release =
			  rs.getString("years"); added = rs.getString("added"); img
			  =rs.getString("imgGame"); price = rs.getFloat("price"); desc
			  =rs.getString("descrizione"); 
			  gioco =  new game(titleGame,release,added,img,price,desc);
			  gameList.add(gioco);
			  }
			 

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				DriverManagerConnectionPool.releaseConnection(connection);
				
				
			}
		}
		String paginaCatalogo = "jsp/catalogo.jsp";
		Iterator<game> it = gameList.iterator();
		int c=0;
		while(it.hasNext()) {
			game g = it.next();
			response.addHeader("titleGame"+c, g.getName());
			 response.addHeader("genere","rpg");
			 response.addHeader("release"+c, g.getAdded());
			  response.addHeader("peg", "18");
			  response.addHeader("desc"+c, g.getDesc());
			  c++;
		}
		  RequestDispatcher view = request.getRequestDispatcher(paginaCatalogo);
		  view.forward(request,response);
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		try {
			db(request,response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		 * try { // This will load the MySQL driver, each DB has its own driver
		 * Class.forName("com.mysql.jdbc.Driver"); // Setup the connection with the DB
		 * connect = DriverManager .getConnection("jdbc:mysql://localhost/gamelist?" +
		 * "user=root&password=root");
		 * 
		 * // Statements allow to issue SQL queries to the database statement =
		 * connect.createStatement(); // Result set get the result of the SQL query
		 * resultSet = statement .executeQuery("SELECT * FROM gamelist.games;");
		 * while(resultSet.next()) { titleGame = resultSet.getString("name"); release =
		 * resultSet.getString("years"); added = resultSet.getString("added"); img =
		 * resultSet.getString("imgGame"); price = resultSet.getFloat("price"); desc =
		 * resultSet.getString("desc");
		 * 
		 * } } catch (Exception e) { e.printStackTrace(); } finally {
		 * 
		 * String paginaCatalogo = "jsp/catalogo.jsp";
		 * 
		 * response.addHeader("titleGame", titleGame); response.addHeader("genere",
		 * "rpg"); response.addHeader("release", release); response.addHeader("peg",
		 * "18"); response.addHeader("desc", desc); RequestDispatcher view =
		 * request.getRequestDispatcher(paginaCatalogo); view.forward(request,response);
		 * }
		 */
        

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
