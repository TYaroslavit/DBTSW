

DROP TABLE IF EXISTS utenti;

CREATE TABLE utenti (	
  nome_utente varchar(50) not null ,
  balance float(2) DEFAULT 0,
  nome varchar(50) not null,
  cognome varchar(50) not null,
  nascita date not null,
  primary key(nome_utente)
);

INSERT INTO utenti values ("pippo",50,"giuseppe","bianchi","1975-03-15");
INSERT INTO utenti values ("micky",50,"lorenzo","bianchi","1975-03-15");
INSERT INTO utenti values ("carmine",50,"carmine","longhi","1975-03-15");
INSERT INTO utenti values ("emmy",50,"cane","rossi","1975-03-15");

