DROP TABLE IF EXISTS ordini;

CREATE TABLE ordini (
  id int not null auto_increment,
  nome_utente varchar(50) not null ,
  price float(2) not null,
  id_game int not null,
  nome char(100) not null,
  buyed datetime not null,
  primary key(id),
  FOREIGN KEY (nome_utente) REFERENCES utenti(nome_utente),
  FOREIGN KEY (id_game) REFERENCES games(id)
);

INSERT INTO ordini values (null,"emmy",4,1,"Elden Ring","2022-05-03 21:00:00");
INSERT INTO ordini values (null,"emmy",4,1,"Elden Ring","2022-06-03 21:00:00");
INSERT INTO ordini values (null,"carmine",4,1,"Elden Ring","2022-05-03 21:00:00");